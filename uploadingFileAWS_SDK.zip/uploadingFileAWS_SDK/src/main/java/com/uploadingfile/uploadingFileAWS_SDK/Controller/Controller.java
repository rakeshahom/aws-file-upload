package com.uploadingfile.uploadingFileAWS_SDK.Controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.util.IOUtils;

@RestController
public class Controller {

	@Autowired
	private AmazonS3 s3Client;
	
	@Value("${s3demofile}")
	private String bucketName;

	@PostMapping("/upload/file")
	public String uploadFile(@RequestParam(name = "file") MultipartFile file) throws IOException {
		File modifiedfield = new File(file.getOriginalFilename());
		FileOutputStream os = new FileOutputStream(modifiedfield);
		os.write(file.getBytes());

		String fileName = System.currentTimeMillis() + "_" + file.getOriginalFilename();
		s3Client.putObject(bucketName, fileName, modifiedfield);
		modifiedfield.delete();
		return "file upload successfully in s3bucket" + fileName;
	}

	@GetMapping("/file/download")
	public ResponseEntity<ByteArrayResource> downloadfileFromS3(@RequestParam(name = "file") String fileName)
			throws IOException {
		S3Object s3Object = s3Client.getObject(bucketName, fileName);
		S3ObjectInputStream objectContent = s3Object.getObjectContent();
		byte[] byteArray = IOUtils.toByteArray(objectContent);
		ByteArrayResource resource = new ByteArrayResource(byteArray);
		return ResponseEntity.ok().contentLength(byteArray.length).header("content-Type", "application/octet-stream")
				.header("content-disposiotion", "attachment;fileName=\"" + fileName + "\"").body(resource);
	}

	@DeleteMapping("/delete/File")
	public String deleteFileFromS3(@RequestParam(name = "file") String fileName) {
		s3Client.deleteObject(bucketName, fileName);
		return "file delete successfully" + fileName;
	}

}
