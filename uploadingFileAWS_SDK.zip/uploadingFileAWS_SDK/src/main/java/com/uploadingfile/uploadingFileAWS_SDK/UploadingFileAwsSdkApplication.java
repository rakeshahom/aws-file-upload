package com.uploadingfile.uploadingFileAWS_SDK;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UploadingFileAwsSdkApplication {

	public static void main(String[] args) {
		SpringApplication.run(UploadingFileAwsSdkApplication.class, args);
	}

}
