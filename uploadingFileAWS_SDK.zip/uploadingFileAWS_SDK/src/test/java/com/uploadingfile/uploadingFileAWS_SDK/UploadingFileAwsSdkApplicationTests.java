package com.uploadingfile.uploadingFileAWS_SDK;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UploadingFileAwsSdkApplicationTests {

	@Test
	void contextLoads() {
	}

}
